package com.naresh;

public class Company {
	
	public void printComapnyDetails() {
		System.out.println("This is Naresh It");
		System.out.println("Lcoated in HYd");
		System.out.println("Providing Trainings in HYd");
	}

}
